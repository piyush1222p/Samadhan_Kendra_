import { Router } from 'express';
import { authenticate, requireRole, ROLES } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import {
  createDepartmentSchema,
  updateDepartmentSchema
} from '../validation/departmentSchemas.js';
import {
  createDepartment,
  listDepartments,
  updateDepartment,
  deleteDepartment
} from '../controllers/departmentController.js'; // adjust if different

const router = Router();

// Only ADMIN or MODERATOR can create
router.post(
  '/',
  authenticate,
  requireRole(ROLES.ADMIN, ROLES.MODERATOR),
  validate(createDepartmentSchema),
  createDepartment
);

// Public or authenticated listing? Decide:
// If public listing: just listDepartments
router.get('/', listDepartments);

// Update (ADMIN or MODERATOR)
router.patch(
  '/:id',
  authenticate,
  requireRole(ROLES.ADMIN, ROLES.MODERATOR),
  validate(updateDepartmentSchema),
  updateDepartment
);

// Delete (ADMIN only)
router.delete(
  '/:id',
  authenticate,
  requireRole(ROLES.ADMIN),
  deleteDepartment
);

export default router;