import { Router } from 'express';
import {
  register,
  login,
  handleRefresh,
  handleLogout
} from '../controllers/authController.js';
import { validate } from '../middleware/validate.js';
import {
  registerSchema,
  loginSchema,
  refreshSchema,
  logoutSchema
} from '../validation/authSchemas.js';

const router = Router();

router.post('/register', validate(registerSchema), register);
router.post('/login', validate(loginSchema), login);
router.post('/refresh', validate(refreshSchema), handleRefresh);
router.post('/logout', validate(logoutSchema), handleLogout);

export default router;