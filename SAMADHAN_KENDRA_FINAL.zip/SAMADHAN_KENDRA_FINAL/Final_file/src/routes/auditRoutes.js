import { Router } from 'express';
import { getAuditLogs } from '../controllers/auditController.js';
import { authRequired } from '../middleware/auth.js';
import { requireRole } from '../middleware/requireRole.js';

const router = Router();
router.get('/', authRequired, requireRole('ADMIN'), getAuditLogs);
export default router;