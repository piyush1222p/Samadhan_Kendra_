import { Router } from 'express';
import { authenticate, requireRole, ROLES } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import {
  createGrievanceSchema,
  updateGrievanceSchema
} from '../validation/grievanceSchemas.js';
import {
  postGrievance as createGrievance,
  getGrievances as listGrievances,
  getGrievanceById as getGrievance,
  updateStatus as updateGrievance,   // or keep original name; align below
  deleteGrievance,
  assign,              // if you have an assign route
  grievanceStats
} from '../controllers/grievanceController.js';

const router = Router();

// Create grievance (authenticated user)
router.post(
  '/',
  authenticate,
  validate(createGrievanceSchema),
  createGrievance
);

// List grievances (public or protected; add authenticate if needed)
router.get('/', listGrievances);

// Stats (ADMIN/MODERATOR maybe)
router.get('/stats', authenticate, requireRole(ROLES.ADMIN, ROLES.MODERATOR), grievanceStats);

// Single grievance
router.get('/:id', getGrievance);

// Update status (ADMIN or MODERATOR) – if you only update status
router.patch(
  '/:id/status',
  authenticate,
  requireRole(ROLES.ADMIN, ROLES.MODERATOR),
  validate(updateGrievanceSchema),
  updateGrievance
);

// Assign (if you support assigning to a moderator)
router.patch(
  '/:id/assign',
  authenticate,
  requireRole(ROLES.ADMIN, ROLES.MODERATOR),
  assign
);

// Delete (ADMIN)
router.delete(
  '/:id',
  authenticate,
  requireRole(ROLES.ADMIN),
  deleteGrievance
);

export default router;