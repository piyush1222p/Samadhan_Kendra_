import { Router } from 'express';
const router = Router();

router.get('/', (_req, res) => {
  res.json({
    status: 'ok',
    service: 'Samadhan Kendra API',
    time: new Date().toISOString()
  });
});

router.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    time: new Date().toISOString()
  });
});

export default router;