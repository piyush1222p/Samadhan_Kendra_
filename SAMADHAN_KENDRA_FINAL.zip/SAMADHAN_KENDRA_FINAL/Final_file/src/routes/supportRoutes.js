import { Router } from 'express';
import { authenticate, requireRole, ROLES } from '../middleware/auth.js';
import { validate } from '../middleware/validate.js';
import {
  createSupportMessageSchema,
  updateSupportMessageSchema
} from '../validation/supportSchemas.js';
import {
  createSupportMessage,
  listSupportMessages,
  getSupportMessage,
  updateSupportMessage,
  deleteSupportMessage,
  supportStats
} from '../controllers/supportController.js';

const router = Router();

// Create (any authenticated user)
router.post(
  '/',
  authenticate,
  validate(createSupportMessageSchema),
  createSupportMessage
);

// List (owner restricted unless elevated)
router.get(
  '/',
  authenticate,         // remove authenticate if you want public listing of own? (not typical)
  listSupportMessages
);

// Stats (ADMIN/MODERATOR)
router.get(
  '/stats',
  authenticate,
  requireRole(ROLES.ADMIN, ROLES.MODERATOR),
  supportStats
);

// Single
router.get(
  '/:id',
  authenticate,
  getSupportMessage
);

// Update
router.patch(
  '/:id',
  authenticate,
  validate(updateSupportMessageSchema),
  updateSupportMessage
);

// Delete
router.delete(
  '/:id',
  authenticate,
  deleteSupportMessage
);

export default router;