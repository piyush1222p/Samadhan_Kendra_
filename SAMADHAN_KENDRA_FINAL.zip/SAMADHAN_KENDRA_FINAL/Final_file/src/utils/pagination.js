export function parsePagination(query) {
  const page = Math.max(parseInt(query.page || '1', 10), 1);
  const limit = Math.min(Math.max(parseInt(query.limit || '20', 10), 1), 100);
  const skip = (page - 1) * limit;
  return { page, limit, skip };
}

export function buildSort(sortParam, defaultSort = '-createdAt') {
  const sort = sortParam || defaultSort;
  // support comma-separated multi fields
  const fields = sort.split(',').map(f => f.trim()).filter(Boolean);
  const sortObj = {};
  for (const f of fields) {
    if (f.startsWith('-')) sortObj[f.slice(1)] = -1;
    else sortObj[f] = 1;
  }
  return sortObj;
}