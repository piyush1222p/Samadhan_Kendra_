import mongoose from 'mongoose';
import bcrypt from 'bcrypt';

/**
 * Centralized role & status definitions so the rest of the codebase
 * can import (e.g. for validation, UI dropdowns, seeding, access control).
 */
export const ROLE_VALUES = ['USER', 'MODERATOR', 'ADMIN'];
export const STATUS_VALUES = ['ACTIVE', 'INACTIVE', 'SUSPENDED'];

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      unique: true,
      index: true,
      required: true,
      trim: true
    },
    email: {
      type: String,
      unique: true,
      sparse: true,          // allows multiple docs with null/undefined
      lowercase: true,
      trim: true
    },
    passwordHash: {
      type: String,
      required: true
    },
    role: {
      type: String,
      enum: ROLE_VALUES,
      default: 'USER',
      index: true
    },
    status: {
      type: String,
      enum: STATUS_VALUES,
      default: 'ACTIVE'
    },
    points: {
      type: Number,
      default: 0,
      min: 0
    },
    phone: {
      type: String,
      trim: true
    },
    city: {
      type: String,
      trim: true
    }
  },
  {
    timestamps: true
  }
);

/**
 * Pre-save normalization:
 *  - Force role & status uppercase (defensive; tolerates mixed-case input).
 */
userSchema.pre('save', function (next) {
  if (this.role) this.role = this.role.toUpperCase();
  if (this.status) this.status = this.status.toUpperCase();
  next();
});

/**
 * Instance method to compare a plain password with the stored hash.
 * (Used in auth controller during login.)
 */
userSchema.methods.verifyPassword = function (plain) {
  return bcrypt.compare(plain, this.passwordHash);
};

/**
 * Static helper to create a password hash (optional convenience).
 */
userSchema.statics.hashPassword = async function (plain) {
  const saltRounds = 10;
  return bcrypt.hash(plain, saltRounds);
};

/**
 * toJSON transformation:
 * Remove sensitive/internal fields when sending user docs to clients.
 */
userSchema.methods.toSafeObject = function () {
  const { _id, username, email, role, status, points, phone, city, createdAt, updatedAt } = this;
  return { id: _id.toString(), username, email, role, status, points, phone, city, createdAt, updatedAt };
};

userSchema.set('toJSON', {
  transform: (_doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    delete ret.passwordHash;
    return ret;
  }
});

/**
 * Useful compound indexes (optional but can help queries):
 *  - Quickly find active users by role or username.
 */
userSchema.index({ role: 1, status: 1 });
userSchema.index({ username: 1, status: 1 });

export const User = mongoose.model('User', userSchema);