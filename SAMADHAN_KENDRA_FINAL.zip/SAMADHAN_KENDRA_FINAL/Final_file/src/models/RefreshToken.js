import mongoose from 'mongoose';
const { ObjectId } = mongoose.Schema.Types;

const refreshTokenSchema = new mongoose.Schema({
  token: { type: String, unique: true, required: true },
  user: { type: ObjectId, ref: 'User', required: true, index: true },
  expiresAt: { type: Date, index: true }
}, { timestamps: true });

refreshTokenSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

export const RefreshToken = mongoose.model('RefreshToken', refreshTokenSchema);