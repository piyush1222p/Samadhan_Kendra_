import mongoose from 'mongoose';
const { ObjectId } = mongoose.Schema.Types;

/**
 * Priority mapping:
 * 1 = LOW
 * 2 = MEDIUM
 * 3 = HIGH
 * 4 = URGENT
 */
export const PRIORITY_VALUES = [1, 2, 3, 4];
export const PRIORITY_LABELS = {
  1: 'LOW',
  2: 'MEDIUM',
  3: 'HIGH',
  4: 'URGENT'
};

export const STATUS_VALUES = [
  'REPORTED',
  'INVESTIGATING',
  'IN_PROGRESS',
  'RESOLVED'
];

const grievanceSchema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, required: true, trim: true },
    // Removed inline index: true for single fields to avoid redundant indexes
    priority: { type: Number, enum: PRIORITY_VALUES, default: 2 },
    status: { type: String, enum: STATUS_VALUES, default: 'REPORTED' },
    reporter: { type: ObjectId, ref: 'User', required: true },
    department: { type: ObjectId, ref: 'Department', required: true },
    assignee: { type: ObjectId, ref: 'User' },
    adminNotes: { type: String, trim: true }
  },
  { timestamps: true }
);

// Virtual
grievanceSchema.virtual('priorityLabel').get(function () {
  return PRIORITY_LABELS[this.priority] || 'UNKNOWN';
});

// Instance method (DTO)
grievanceSchema.methods.toSafeObject = function () {
  const {
    _id,
    title,
    description,
    priority,
    status,
    reporter,
    department,
    assignee,
    adminNotes,
    createdAt,
    updatedAt
  } = this;

  return {
    id: _id.toString(),
    title,
    description,
    priority,
    priorityLabel: PRIORITY_LABELS[priority] || null,
    status,
    reporter,
    department,
    assignee,
    adminNotes,
    createdAt,
    updatedAt
  };
};

// Statics
grievanceSchema.statics.STATUS_VALUES = STATUS_VALUES;
grievanceSchema.statics.PRIORITY_VALUES = PRIORITY_VALUES;
grievanceSchema.statics.PRIORITY_LABELS = PRIORITY_LABELS;

// Compound / text indexes (lean set)
grievanceSchema.index({ status: 1, priority: 1, createdAt: -1 });
grievanceSchema.index({ department: 1, createdAt: -1 });
grievanceSchema.index({ reporter: 1, createdAt: -1 });
grievanceSchema.index({ assignee: 1, status: 1 });
grievanceSchema.index({ title: 'text', description: 'text' });

// OPTIONAL: Uncomment only if you really need priority-only queries
// grievanceSchema.index({ priority: 1 });

export const Grievance = mongoose.model('Grievance', grievanceSchema);