import mongoose from 'mongoose';
const { ObjectId } = mongoose.Schema.Types;

const auditLogSchema = new mongoose.Schema({
  actor: { type: ObjectId, ref: 'User' },
  action: String,
  resource: String,
  resourceId: { type: String },
  details: String,
  ip: String
}, { timestamps: { createdAt: true, updatedAt: false } });

auditLogSchema.index({ createdAt: -1 });

export const AuditLog = mongoose.model('AuditLog', auditLogSchema);