import express from 'express';
import dotenv from 'dotenv';
import mongoose from 'mongoose';
import cors from 'cors';
// import helmet from 'helmet'; // (optional) uncomment to add security headers

// Load environment variables
dotenv.config();

// Route imports
import healthRoutes from './routes/healthRoutes.js';
import departmentRoutes from './routes/departmentRoutes.js';
import grievanceRoutes from './routes/grievanceRoutes.js';
import supportRoutes from './routes/supportRoutes.js';
// import authRoutes from './routes/authRoutes.js'; // when you create auth routes

// Rate limiting & progressive delay utilities (Option 3)
import {
  generalLimiter,
  // authLimiter,            // (not needed here directly if you use applyAuthProtections)
  applyAuthProtections
} from './middleware/rateLimit.js';

const app = express();

// Let Express know it can trust X-Forwarded-* headers (needed if behind a proxy / load balancer)
app.set('trust proxy', 1);

// Core middlewares
app.use(cors());
app.use(express.json());
// app.use(helmet()); // (optional) enable if you want default security headers

// Silence favicon 404 noise
app.get('/favicon.ico', (_req, res) => res.status(204).end());

// 1. Public health & root routes FIRST (kept outside global limiter)
app.use('/', healthRoutes);

// 2. Global rate limiter AFTER health routes
app.use(generalLimiter);

// 3. API routes
app.use('/api/departments', departmentRoutes);
app.use('/api/grievances', grievanceRoutes);
app.use('/api/support', supportRoutes);

// 4. Auth routes (when you add them):
// import authRoutes above and then uncomment the next line
// app.use('/api/auth', applyAuthProtections(authRoutes));

// 5. 404 handler (only reached if no earlier route matched)
app.use((req, res, _next) => {
  res.status(404).json({ detail: 'Not found' });
});

// 6. Central error handler
app.use((err, req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  const payload = {
    status: 'error',
    message: err.message || 'Internal Server Error'
  };
  // Include stack only in development for debugging
  if (process.env.NODE_ENV !== 'production') {
    payload.stack = err.stack;
  }
  // Basic logging (will be replaced later by structured logger in enhancement B)
  console.error('Error handler caught:', err);
  if (!res.headersSent) {
    res.status(status).json(payload);
  }
});

// ---- Database + Server Startup ----
const PORT = process.env.PORT || 8000;
const MONGO_URI =
  process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/samadhan';

// You can perform a simple required env validation if desired
// const requiredEnv = ['JWT_SECRET'];
// requiredEnv.forEach(v => {
//   if (!process.env[v]) {
//     console.warn(`Warning: Missing environment variable ${v}`);
//   }
// });

let server; // will store the http server instance

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    server = app.listen(PORT, () => {
      console.log(`Samadhan Mongo API running on http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error('Mongo connection failed', err);
    process.exit(1);
  });

// Graceful shutdown
function shutdown(signal) {
  console.log(`\n${signal} received. Shutting down gracefully...`);
  Promise.resolve()
    .then(() => server && server.close())
    .then(() => mongoose.connection.close())
    .then(() => {
      console.log('Shutdown complete. Bye!');
      process.exit(0);
    })
    .catch(err => {
      console.error('Error during shutdown', err);
      process.exit(1);
    });
}

['SIGINT', 'SIGTERM'].forEach(sig => {
  process.on(sig, () => shutdown(sig));
});

// Export app for tests (supertest etc.) without starting another server
export default app;