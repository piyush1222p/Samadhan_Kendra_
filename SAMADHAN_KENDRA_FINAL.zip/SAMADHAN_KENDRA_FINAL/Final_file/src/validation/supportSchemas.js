import Joi from 'joi';

export const createSupportMessageSchema = Joi.object({
  subject: Joi.string().min(3).max(120).required(),
  message: Joi.string().min(5).max(3000).required(),
  priority: Joi.string().valid('LOW','NORMAL','HIGH').optional(),
  departmentId: Joi.string().hex().length(24).optional()
});

export const updateSupportMessageSchema = Joi.object({
  subject: Joi.string().min(3).max(120),
  message: Joi.string().min(5).max(3000),
  status: Joi.string().valid('OPEN','IN_PROGRESS','RESOLVED','CLOSED'),
  priority: Joi.string().valid('LOW','NORMAL','HIGH'),
  departmentId: Joi.string().hex().length(24),
  assignedTo: Joi.string().hex().length(24)
}).min(1);