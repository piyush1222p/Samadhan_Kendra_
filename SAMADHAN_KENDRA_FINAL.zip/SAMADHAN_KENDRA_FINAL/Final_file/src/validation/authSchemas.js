import Joi from 'joi';

export const registerSchema = Joi.object({
  username: Joi.string().alphanum().min(3).max(30).required(),
  email: Joi.string().email().optional().allow(null, ''),
  password: Joi.string().min(6).max(128).required(),
  role: Joi.string().valid('USER','MODERATOR','ADMIN').optional()
});

export const loginSchema = Joi.object({
  username: Joi.string().alphanum().min(3).max(30),
  email: Joi.string().email(),
  password: Joi.string().required()
})
  // require at least one of username or email
  .or('username', 'email');

export const refreshSchema = Joi.object({
  refreshToken: Joi.string().required()
});

export const logoutSchema = refreshSchema;