import Joi from 'joi';

export const createGrievanceSchema = Joi.object({
  title: Joi.string().min(4).max(200).required(),
  description: Joi.string().min(10).max(5000).required(),
  priority: Joi.number().integer().valid(1,2,3,4).default(2),
  department: Joi.string().hex().length(24).required()
});

export const listGrievancesQuerySchema = Joi.object({
  page: Joi.number().integer().min(1).optional(),
  pageSize: Joi.number().integer().min(1).max(100).optional(),
  status: Joi.string().valid('REPORTED','INVESTIGATING','IN_PROGRESS','RESOLVED').optional(),
  priority: Joi.number().integer().valid(1,2,3,4).optional(),
  department: Joi.string().hex().length(24).optional(),
  reporter: Joi.string().hex().length(24).optional(),
  assignee: Joi.string().hex().length(24).optional(),
  q: Joi.string().min(2).max(120).optional()
});

export const updateGrievanceSchema = Joi.object({
  title: Joi.string().min(4).max(200),
  description: Joi.string().min(10).max(5000),
  priority: Joi.number().integer().valid(1,2,3,4),
  status: Joi.string().valid('REPORTED','INVESTIGATING','IN_PROGRESS','RESOLVED'),
  assignee: Joi.string().hex().length(24).allow(null),
  adminNotes: Joi.string().max(3000).allow('', null)
}).min(1);