import Joi from 'joi';

export const createDepartmentSchema = Joi.object({
  name: Joi.string().min(2).max(60).required(),
  description: Joi.string().max(300).allow('', null),
  isActive: Joi.boolean().optional()
});

export const updateDepartmentSchema = Joi.object({
  name: Joi.string().min(2).max(60),
  description: Joi.string().max(300).allow('', null),
  isActive: Joi.boolean()
}).min(1);