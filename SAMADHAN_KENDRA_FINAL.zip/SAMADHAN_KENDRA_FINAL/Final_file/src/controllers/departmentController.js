import { Department } from '../models/Department.js';

/**
 * Create a department
 * POST /api/departments
 */
export async function createDepartment(req, res, next) {
  try {
    const { name, description, isActive } = req.body;
    const existing = await Department.findOne({ name });
    if (existing) {
      return res.status(409).json({ status: 'fail', message: 'Department name already exists' });
    }
    const dept = await Department.create({ name, description, isActive });
    return res.status(201).json({ status: 'success', data: { department: dept } });
  } catch (err) {
    next(err);
  }
}

/**
 * List departments
 * GET /api/departments
 */
export async function listDepartments(req, res, next) {
  try {
    const { page = 1, pageSize = 20, onlyActive } = req.query;
    const p = Math.max(parseInt(page, 10) || 1, 1);
    const size = Math.min(Math.max(parseInt(pageSize, 10) || 20, 1), 100);

    const filter = {};
    if (onlyActive === 'true') filter.isActive = true;

    const [items, total] = await Promise.all([
      Department.find(filter)
        .skip((p - 1) * size)
        .limit(size)
        .lean(),
      Department.countDocuments(filter)
    ]);

    res.json({
      status: 'success',
      data: items,
      meta: {
        page: p,
        pageSize: size,
        total,
        totalPages: Math.ceil(total / size) || 1
      }
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Update department
 * PATCH /api/departments/:id
 */
export async function updateDepartment(req, res, next) {
  try {
    const { id } = req.params;
    const update = req.body;

    if (update.name) {
      const nameExists = await Department.findOne({ name: update.name, _id: { $ne: id } });
      if (nameExists) {
        return res.status(409).json({ status: 'fail', message: 'Another department already uses that name' });
      }
    }

    const dept = await Department.findByIdAndUpdate(id, update, { new: true });
    if (!dept) {
      return res.status(404).json({ status: 'fail', message: 'Department not found' });
    }
    res.json({ status: 'success', data: { department: dept } });
  } catch (err) {
    next(err);
  }
}

/**
 * Delete department
 * DELETE /api/departments/:id
 */
export async function deleteDepartment(req, res, next) {
  try {
    const { id } = req.params;
    const deleted = await Department.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ status: 'fail', message: 'Department not found' });
    }
    res.json({ status: 'success', message: 'Department deleted' });
  } catch (err) {
    next(err);
  }
}