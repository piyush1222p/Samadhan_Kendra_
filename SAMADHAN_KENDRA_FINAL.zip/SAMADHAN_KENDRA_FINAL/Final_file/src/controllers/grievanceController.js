import mongoose from 'mongoose';
import { Grievance, PRIORITY_LABELS } from '../models/Grievance.js';
import { Department } from '../models/Department.js';
import { User } from '../models/User.js';
import { parsePagination, buildSort } from '../utils/pagination.js';

// GET /api/grievances
export const getGrievances = async (req, res) => {
  const { page, limit, skip } = parsePagination(req.query);
  const { status, priority, department, reporter, assignee, search, sort } = req.query;

  const q = {};
  if (status) q.status = status;
  if (priority) q.priority = Number(priority);
  if (department) q.department = department;
  if (reporter) q.reporter = reporter;
  if (assignee) q.assignee = assignee;
  if (search) {
    const rx = new RegExp(search, 'i');
    q.$or = [{ title: rx }, { description: rx }];
  }

  const sortObj = buildSort(sort, '-createdAt');

  const [items, total] = await Promise.all([
    Grievance.find(q)
      .populate('department', 'name')
      .populate('reporter', 'username role')
      .populate('assignee', 'username role')
      .sort(sortObj)
      .skip(skip)
      .limit(limit)
      .lean(),
    Grievance.countDocuments(q)
  ]);

  // Decorate priority labels in response (since lean removed virtual)
  const decorated = items.map(g => ({
    ...g,
    id: g._id?.toString(),
    priorityLabel: PRIORITY_LABELS[g.priority] || null
  }));

  res.json({
    page,
    limit,
    total,
    pages: Math.max(1, Math.ceil(total / limit)),
    sort: sortObj,
    filters: q,
    items: decorated
  });
};

// POST /api/grievances
export const postGrievance = async (req, res) => {
  const { title, description, priority, department } = req.body;

  const dept = await Department.findById(department);
  if (!dept) return res.status(404).json({ message: 'Department not found' });

  const grievance = await Grievance.create({
    title,
    description,
    priority,
    department: dept._id,
    reporter: req.user?._id
  });

  res.status(201).json(grievance.toSafeObject());
};

// GET /api/grievances/:id
export const getGrievanceById = async (req, res) => {
  const g = await Grievance.findById(req.params.id)
    .populate('department', 'name')
    .populate('reporter', 'username role')
    .populate('assignee', 'username role');

  if (!g) return res.status(404).json({ message: 'Grievance not found' });
  res.json(g.toSafeObject());
};

// PATCH /api/grievances/:id/status
export const updateStatus = async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;

  const g = await Grievance.findById(id);
  if (!g) return res.status(404).json({ message: 'Grievance not found' });

  g.status = status;
  await g.save();
  res.json(g.toSafeObject());
};

// PATCH /api/grievances/:id/assign
export const assign = async (req, res) => {
  const { id } = req.params;
  const { assigneeUserId } = req.body;

  const user = await User.findById(assigneeUserId);
  if (!user) return res.status(404).json({ message: 'User not found' });

  const g = await Grievance.findById(id);
  if (!g) return res.status(404).json({ message: 'Grievance not found' });

  g.assignee = user._id;
  await g.save();
  res.json(g.toSafeObject());
};

// DELETE /api/grievances/:id
export const deleteGrievance = async (req, res) => {
  const g = await Grievance.findById(req.params.id);
  if (!g) return res.status(404).json({ message: 'Grievance not found' });
  await g.deleteOne();
  res.json({ message: 'Deleted' });
};

// GET /api/grievances/stats
export const grievanceStats = async (_req, res) => {
  const pipeline = [
    {
      $group: {
        _id: null,
        total: { $sum: 1 }
      }
    }
  ];

  const statusGroup = [
    { $group: { _id: '$status', count: { $sum: 1 } } }
  ];

  const priorityGroup = [
    { $group: { _id: '$priority', count: { $sum: 1 } } }
  ];

  const deptGroup = [
    { $group: { _id: '$department', count: { $sum: 1 } } },
    {
      $lookup: {
        from: 'departments',
        localField: '_id',
        foreignField: '_id',
        as: 'department'
      }
    },
    { $unwind: '$department' },
    {
      $project: {
        _id: 0,
        departmentId: '$department._id',
        department: '$department.name',
        count: 1
      }
    }
  ];

  const [statusStats, priorityStats, deptStats, total] = await Promise.all([
    Grievance.aggregate(statusGroup),
    Grievance.aggregate(priorityGroup),
    Grievance.aggregate(deptGroup),
    Grievance.countDocuments()
  ]);

  res.json({
    total,
    byStatus: statusStats.reduce((acc, s) => {
      acc[s._id] = s.count;
      return acc;
    }, {}),
    byPriority: priorityStats.reduce((acc, p) => {
      acc[p._id] = {
        count: p.count,
        label: PRIORITY_LABELS[p._id] || null
      };
      return acc;
    }, {}),
    byDepartment: deptStats
  });
};