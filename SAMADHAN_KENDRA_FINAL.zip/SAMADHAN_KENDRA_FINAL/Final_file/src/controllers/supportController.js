import { SupportMessage, SUPPORT_STATUS } from '../models/SupportMessage.js';
import { Department } from '../models/Department.js';
import { User } from '../models/User.js';

// CREATE
export async function createSupportMessage(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ status: 'fail', message: 'Not authenticated' });
    }
    const { subject, message, priority, departmentId } = req.body;

    let department = null;
    if (departmentId) {
      department = await Department.findById(departmentId);
      if (!department) {
        return res.status(404).json({ status: 'fail', message: 'Department not found' });
      }
    }

    const doc = await SupportMessage.create({
      subject,
      message,
      priority,
      department: department ? department._id : undefined,
      user: req.user.id
    });

    res.status(201).json({ status: 'success', data: { supportMessage: doc } });
  } catch (err) {
    next(err);
  }
}

// LIST (Admins/Moderators see all; normal users see their own)
export async function listSupportMessages(req, res, next) {
  try {
    const {
      page = 1,
      pageSize = 20,
      status,
      priority,
      userId
    } = req.query;

    const p = Math.max(parseInt(page, 10) || 1, 1);
    const size = Math.min(Math.max(parseInt(pageSize, 10) || 20, 1), 100);

    const filter = {};

    // Only allow arbitrary userId filter for elevated roles
    if (userId) {
      if (!req.user || !['ADMIN','MODERATOR'].includes(req.user.role)) {
        return res.status(403).json({ status: 'fail', message: 'Forbidden userId filter' });
      }
      filter.user = userId;
    }

    if (status) filter.status = status;
    if (priority) filter.priority = priority;

    // If not elevated role, restrict to own messages
    if (!req.user || !['ADMIN','MODERATOR'].includes(req.user.role)) {
      if (!req.user) {
        return res.status(401).json({ status: 'fail', message: 'Not authenticated' });
      }
      filter.user = req.user.id;
    }

    const [items, total] = await Promise.all([
      SupportMessage.find(filter)
        .populate('user', 'username email role')
        .populate('assignedTo', 'username email role')
        .populate('department', 'name')
        .skip((p - 1) * size)
        .limit(size)
        .sort({ createdAt: -1 })
        .lean(),
      SupportMessage.countDocuments(filter)
    ]);

    res.json({
      status: 'success',
      data: items,
      meta: {
        page: p,
        pageSize: size,
        total,
        totalPages: Math.ceil(total / size) || 1
      }
    });
  } catch (err) {
    next(err);
  }
}

// GET SINGLE
export async function getSupportMessage(req, res, next) {
  try {
    const { id } = req.params;
    const sm = await SupportMessage.findById(id)
      .populate('user', 'username email role')
      .populate('assignedTo', 'username email role')
      .populate('department', 'name');

    if (!sm) {
      return res.status(404).json({ status: 'fail', message: 'Support message not found' });
    }

    // Authorization: owner or elevated
    if (!req.user) {
      return res.status(401).json({ status: 'fail', message: 'Not authenticated' });
    }
    if (
      sm.user._id.toString() !== req.user.id &&
      !['ADMIN','MODERATOR'].includes(req.user.role)
    ) {
      return res.status(403).json({ status: 'fail', message: 'Forbidden' });
    }

    res.json({ status: 'success', data: { supportMessage: sm } });
  } catch (err) {
    next(err);
  }
}

// UPDATE (elevated OR owner for limited fields)
export async function updateSupportMessage(req, res, next) {
  try {
    const { id } = req.params;
    const { status, departmentId, assignedTo, ...rest } = req.body;

    const sm = await SupportMessage.findById(id);
    if (!sm) {
      return res.status(404).json({ status: 'fail', message: 'Support message not found' });
    }
    if (!req.user) return res.status(401).json({ status: 'fail', message: 'Not authenticated' });

    const isOwner = sm.user.toString() === req.user.id;
    const elevated = ['ADMIN','MODERATOR'].includes(req.user.role);

    // Owner can edit subject/message only (not status/assignment)
    if (!elevated && !isOwner) {
      return res.status(403).json({ status: 'fail', message: 'Forbidden' });
    }

    if (!elevated) {
      // Filter rest to allowed keys
      const allowed = {};
      if (typeof rest.subject === 'string') allowed.subject = rest.subject;
      if (typeof rest.message === 'string') allowed.message = rest.message;
      Object.assign(sm, allowed);
    } else {
      // Elevated can change everything
      Object.assign(sm, rest);

      if (status) {
        if (!Object.values(SUPPORT_STATUS).includes(status)) {
          return res.status(400).json({ status: 'fail', message: 'Invalid status' });
        }
        sm.status = status;
      }
      if (departmentId) {
        const dep = await Department.findById(departmentId);
        if (!dep) return res.status(404).json({ status: 'fail', message: 'Department not found' });
        sm.department = departmentId;
      }
      if (assignedTo) {
        const user = await User.findById(assignedTo);
        if (!user) return res.status(404).json({ status: 'fail', message: 'Assignee user not found' });
        sm.assignedTo = assignedTo;
      }
    }

    await sm.save();
    const populated = await sm.populate([
      { path: 'user', select: 'username email role' },
      { path: 'assignedTo', select: 'username email role' },
      { path: 'department', select: 'name' }
    ]);

    res.json({ status: 'success', data: { supportMessage: populated } });
  } catch (err) {
    next(err);
  }
}

// DELETE (elevated or owner if still OPEN)
export async function deleteSupportMessage(req, res, next) {
  try {
    const { id } = req.params;
    const sm = await SupportMessage.findById(id);
    if (!sm) return res.status(404).json({ status: 'fail', message: 'Support message not found' });
    if (!req.user) return res.status(401).json({ status: 'fail', message: 'Not authenticated' });

    const isOwner = sm.user.toString() === req.user.id;
    const elevated = ['ADMIN','MODERATOR'].includes(req.user.role);

    if (!elevated) {
      if (!isOwner) return res.status(403).json({ status: 'fail', message: 'Forbidden' });
      if (sm.status !== SUPPORT_STATUS.OPEN) {
        return res.status(400).json({ status: 'fail', message: 'Cannot delete after processing started' });
      }
    }

    await sm.deleteOne();
    res.json({ status: 'success', message: 'Support message deleted' });
  } catch (err) {
    next(err);
  }
}

// STATS (elevated)
export async function supportStats(_req, res, next) {
  try {
    const agg = await SupportMessage.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } }
    ]);
    const stats = agg.reduce((acc, row) => {
      acc[row._id] = row.count;
      return acc;
    }, {});
    res.json({ status: 'success', data: stats });
  } catch (err) {
    next(err);
  }
}