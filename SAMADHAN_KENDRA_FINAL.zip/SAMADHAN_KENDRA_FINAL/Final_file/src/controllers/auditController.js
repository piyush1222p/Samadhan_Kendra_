import { listAudit } from '../services/auditService.js';

export async function getAuditLogs(req, res, next) {
  try {
    const logs = await listAudit();
    res.json(logs.map(l => ({
      id: l._id,
      timestamp: l.createdAt,
      adminUser: l.actor?.username || null,
      action: l.action,
      resource: l.resource,
      resource_id: l.resourceId,
      details: l.details,
      ipAddress: l.ip
    })));
  } catch (e) { next(e); }
}