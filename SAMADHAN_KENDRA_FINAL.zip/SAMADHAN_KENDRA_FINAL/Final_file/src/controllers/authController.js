import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { User } from '../models/User.js';  // Named import (matches your model)

const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET || 'dev_access_secret';
const REFRESH_TOKEN_SECRET = process.env.REFRESH_TOKEN_SECRET || 'dev_refresh_secret';

function generateTokens(user) {
  const payload = { userId: user._id.toString(), role: user.role };
  const accessToken = jwt.sign(payload, ACCESS_TOKEN_SECRET, { expiresIn: '15m' });
  const refreshToken = jwt.sign(payload, REFRESH_TOKEN_SECRET, { expiresIn: '7d' });
  return { accessToken, refreshToken };
}

// REGISTER
export async function register(req, res, next) {
  try {
    const { username, email, password, role } = req.body;

    // Check duplicates on username or email (if provided)
    const dupUser = await User.findOne({ $or: [{ username }, { email }] });
    if (dupUser) {
      return res.status(409).json({ status: 'fail', message: 'Username or email already in use' });
    }

    const passwordHash = await User.hashPassword(password);

    const user = await User.create({
      username,
      email: email || null,
      passwordHash,
      role: role || 'USER'
    });

    const { accessToken, refreshToken } = generateTokens(user);

    return res.status(201).json({
      status: 'success',
      data: {
        user: user.toSafeObject(),
        accessToken,
        refreshToken
      }
    });
  } catch (err) {
    next(err);
  }
}

// LOGIN (allow login via username OR email)
export async function login(req, res, next) {
  try {
    const { username, email, password } = req.body;

    if (!username && !email) {
      return res.status(400).json({ status: 'fail', message: 'Provide username or email' });
    }

    const user = await User.findOne(
      username
        ? { username }
        : { email }
    );

    if (!user) {
      return res.status(401).json({ status: 'fail', message: 'Invalid credentials' });
    }

    const ok = await user.verifyPassword(password);
    if (!ok) {
      return res.status(401).json({ status: 'fail', message: 'Invalid credentials' });
    }

    const { accessToken, refreshToken } = generateTokens(user);

    return res.json({
      status: 'success',
      data: {
        user: user.toSafeObject(),
        accessToken,
        refreshToken
      }
    });
  } catch (err) {
    next(err);
  }
}

// REFRESH
export async function handleRefresh(req, res, next) {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      return res.status(400).json({ status: 'fail', message: 'refreshToken required' });
    }

    let payload;
    try {
      payload = jwt.verify(refreshToken, REFRESH_TOKEN_SECRET);
    } catch {
      return res.status(401).json({ status: 'fail', message: 'Invalid or expired refresh token' });
    }

    const accessToken = jwt.sign(
      { userId: payload.userId, role: payload.role },
      ACCESS_TOKEN_SECRET,
      { expiresIn: '15m' }
    );

    return res.json({ status: 'success', accessToken });
  } catch (err) {
    next(err);
  }
}

// LOGOUT (placeholder)
export async function handleLogout(_req, res, next) {
  try {
    return res.json({ status: 'success', message: 'Logged out' });
  } catch (err) {
    next(err);
  }
}

// CURRENT USER
export async function me(req, res, next) {
  try {
    if (!req.user) {
      return res.status(401).json({ status: 'fail', message: 'Not authenticated' });
    }
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ status: 'fail', message: 'User not found' });
    }
    return res.json({ status: 'success', data: { user: user.toSafeObject() } });
  } catch (err) {
    next(err);
  }
}