export const requireRole = (...allowed) => {
  const normalized = allowed.map(r => r.toUpperCase());
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: 'Not authenticated' });
    }
    const role = (req.user.role || '').toUpperCase();
    if (!normalized.includes(role)) {
      return res.status(403).json({ message: `Forbidden: requires one of [${normalized.join(', ')}]` });
    }
    next();
  };
};