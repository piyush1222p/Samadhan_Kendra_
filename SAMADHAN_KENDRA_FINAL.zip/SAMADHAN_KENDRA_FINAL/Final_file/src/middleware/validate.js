import Joi from 'joi';

/**
 * Generic validation middleware using Joi schemas.
 * Usage in routes:
 *   router.post('/path', validate(mySchema), handler)
 *   router.get('/path', validate(querySchema, 'query'), handler)
 *
 * @param {Joi.ObjectSchema} schema - Joi schema
 * @param {'body'|'query'|'params'} property - request property to validate
 */
export function validate(schema, property = 'body') {
  return (req, res, next) => {
    if (!schema || !schema.validate) {
      return next(new Error('Invalid Joi schema passed to validate()'));
    }

    const data = req[property];

    const options = {
      abortEarly: false,      // report all errors
      stripUnknown: true,     // remove unknown keys
      convert: true           // allow type casting (strings to numbers, etc.)
    };

    const { error, value } = schema.validate(data, options);

    if (error) {
      return res.status(400).json({
        status: 'fail',
        message: 'Validation error',
        details: error.details.map(d => ({
          message: d.message,
          path: d.path.join('.'),
          type: d.type
        }))
      });
    }

    // Put the cleaned data back
    req[property] = value;
    return next();
  };
}