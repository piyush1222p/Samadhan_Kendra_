import rateLimit from 'express-rate-limit';

/*
 Environment variables you can set (all optional):
 RATE_LIMIT_GENERAL_MAX (default 300)
 RATE_LIMIT_AUTH_MAX (default 10)
 SLOWDOWN_AUTH_AFTER (default 5)
 SLOWDOWN_AUTH_DELAY (default 500)          // base incremental delay in ms
 SLOWDOWN_AUTH_MAX_DELAY (default 5000)     // cap per-request delay
 SLOWDOWN_AUTH_WINDOW_MS (default 300000)   // 5 minutes
*/

const GENERAL_MAX = parseInt(process.env.RATE_LIMIT_GENERAL_MAX || '300', 10);
const AUTH_MAX = parseInt(process.env.RATE_LIMIT_AUTH_MAX || '10', 10);
const DELAY_AFTER = parseInt(process.env.SLOWDOWN_AUTH_AFTER || '5', 10);
const BASE_DELAY = parseInt(process.env.SLOWDOWN_AUTH_DELAY || '500', 10);
const MAX_DELAY = parseInt(process.env.SLOWDOWN_AUTH_MAX_DELAY || '5000', 10);
const WINDOW_MS = parseInt(process.env.SLOWDOWN_AUTH_WINDOW_MS || (5 * 60 * 1000).toString(), 10);

// In‑memory attempt store: Map<ip, { first:number, count:number }>
const attemptStore = new Map();

// Cleanup routine to avoid memory leak
const CLEAN_INTERVAL_MS = 60 * 1000; // run every 1 min
let lastCleanup = Date.now();

function cleanup() {
  const now = Date.now();
  if (now - lastCleanup < CLEAN_INTERVAL_MS) return;
  lastCleanup = now;
  for (const [ip, entry] of attemptStore.entries()) {
    if (now - entry.first > WINDOW_MS) {
      attemptStore.delete(ip);
    }
  }
}

// Progressive delay middleware
function progressiveDelay(req, res, next) {
  cleanup();

  // Extract IP (works with trust proxy if set in app)
  const ip = (req.ip || req.connection?.remoteAddress || '').trim() || 'unknown';
  const now = Date.now();

  let entry = attemptStore.get(ip);
  if (!entry || (now - entry.first > WINDOW_MS)) {
    entry = { first: now, count: 0 };
  }
  entry.count += 1;
  attemptStore.set(ip, entry);

  if (entry.count <= DELAY_AFTER) {
    return next();
  }

  const over = entry.count - DELAY_AFTER;
  let delay = over * BASE_DELAY;
  if (delay > MAX_DELAY) delay = MAX_DELAY;

  // Optional: attach info for logging
  req.rateSlowInfo = { ip, count: entry.count, delay };

  setTimeout(next, delay);
}

// General global limiter (fixed)
export const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: GENERAL_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    status: 'fail',
    message: 'Too many requests from this IP, please try again later.'
  }
});

// Auth hard cap limiter (returns 429 after AUTH_MAX in window)
export const authLimiter = rateLimit({
  windowMs: WINDOW_MS,
  max: AUTH_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    status: 'fail',
    message: 'Too many authentication attempts, please try again later.'
  }
});

// Helper to apply to an auth router
export function applyAuthProtections(router) {
  router.use(progressiveDelay); // adds incremental delay after DELAY_AFTER
  router.use(authLimiter);      // hard cap
  return router;
}

// Utility: reset attempts (useful for tests)
export function resetAuthAttemptStore() {
  attemptStore.clear();
}