import jwt from 'jsonwebtoken';

const ACCESS_TOKEN_SECRET = process.env.ACCESS_TOKEN_SECRET || 'dev_access_secret';

// Central role map (aligns with ROLE_VALUES in User.js)
export const ROLES = Object.freeze({
  USER: 'USER',
  MODERATOR: 'MODERATOR',
  ADMIN: 'ADMIN'
});

/**
 * Authenticate (formerly authRequired):
 * Verifies Bearer token; attaches req.user = { id, role } or returns 401.
 */
export function authenticate(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ status: 'fail', message: 'Missing Authorization header' });
  }
  const token = authHeader.split(' ')[1];
  try {
    const payload = jwt.verify(token, ACCESS_TOKEN_SECRET);
    req.user = { id: payload.userId, role: payload.role };
    return next();
  } catch (_err) {
    return res.status(401).json({ status: 'fail', message: 'Invalid or expired token' });
  }
}

/**
 * Optional auth (do not error if token missing/invalid).
 */
export function authOptional(req, _res, next) {
  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    try {
      const payload = jwt.verify(token, ACCESS_TOKEN_SECRET);
      req.user = { id: payload.userId, role: payload.role };
    } catch {
      // ignore invalid token
    }
  }
  next();
}

/**
 * requireRole(...allowedRoles)
 * Usage: router.post('/admin', authenticate, requireRole(ROLES.ADMIN), handler)
 */
export function requireRole(...allowed) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ status: 'fail', message: 'Not authenticated' });
    }
    if (!allowed.includes(req.user.role)) {
      return res.status(403).json({ status: 'fail', message: 'Forbidden: insufficient role' });
    }
    next();
  };
}

/* If you already implemented these in the controller, remove or ignore.
   If you have them here instead, keep them exported.
*/
// Example placeholders (delete if defined elsewhere):
export async function handleRefresh(req, res, next) {
  return res.status(501).json({ status: 'fail', message: 'Not implemented here (move to controller)' });
}
export async function handleLogout(_req, res, _next) {
  return res.json({ status: 'success', message: 'Logged out (placeholder)' });
}

// Backwards compatibility aliases (if other files still import old names):
export { authenticate as authRequired };