import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import { errorHandler } from './middleware/errorHandler.js';

import authRoutes from './routes/authRoutes.js';
import departmentRoutes from './routes/departmentRoutes.js';
import grievanceRoutes from './routes/grievanceRoutes.js';
import supportRoutes from './routes/supportRoutes.js';
import auditRoutes from './routes/auditRoutes.js';

const app = express();

app.use(helmet());
app.use(cors({ origin: true }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

app.get('/api/health', (req, res) => {
  res.json({ ok: true, ts: new Date().toISOString() });
});

app.use('/api/auth', authRoutes);
app.use('/api/departments', departmentRoutes);
app.use('/api/grievances', grievanceRoutes);
app.use('/api/support', supportRoutes);
app.use('/api/audit', auditRoutes);

app.use((req, res) => res.status(404).json({ detail: 'Not found' }));
app.use(errorHandler);

export default app;