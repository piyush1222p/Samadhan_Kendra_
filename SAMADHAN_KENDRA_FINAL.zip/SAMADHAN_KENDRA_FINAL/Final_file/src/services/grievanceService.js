import { Grievance } from '../models/Grievance.js';
import { addAudit } from './auditService.js';

const STATUS_MAP = new Set(['reported','investigating','in-progress','resolved']);

export function priorityToNumber(p) {
  if (typeof p === 'number') return p;
  const map = { low:1, medium:2, high:3, urgent:4 };
  return map[p] || 2;
}

export async function listGrievances() {
  const docs = await Grievance.find({})
    .populate('reporter','username')
    .populate('department','name')
    .populate('assignee','username')
    .sort({ createdAt: -1 })
    .lean();

  return docs.map(g => ({
    id: g._id,
    title: g.title,
    description: g.description,
    priority: g.priority,
    status: g.status.toLowerCase().replace('_','-'),
    department: g.department?._id,
    department_name: g.department?.name,
    citizen_username: g.reporter?.username,
    assignee_id: g.assignee?._id || null,
    created_at: g.createdAt,
    updated_at: g.updatedAt
  }));
}

export async function createGrievance({ title, description, priority, departmentId, reporterId }) {
  const g = await Grievance.create({
    title,
    description,
    priority: priorityToNumber(priority),
    department: departmentId,
    reporter: reporterId
  });
  await addAudit(reporterId, 'create', 'Grievance', g._id, `Created grievance ${title}`);
  return g;
}

export async function setStatus(id, status, actorId) {
  if (!STATUS_MAP.has(status)) throw Object.assign(new Error('Invalid status'), { status: 400 });
  const normalized = status === 'in-progress' ? 'IN_PROGRESS'
                  : status === 'investigating' ? 'INVESTIGATING'
                  : status === 'resolved' ? 'RESOLVED'
                  : 'REPORTED';
  const updated = await Grievance.findByIdAndUpdate(id, { status: normalized }, { new: true });
  if (!updated) throw Object.assign(new Error('Not found'), { status: 404 });
  await addAudit(actorId, 'status_change', 'Grievance', id, `Changed to ${status}`);
  return updated;
}

export async function assignGrievance(id, assigneeId, actorId) {
  const updated = await Grievance.findByIdAndUpdate(id, { assignee: assigneeId }, { new: true });
  if (!updated) throw Object.assign(new Error('Not found'), { status: 404 });
  await addAudit(actorId, 'assign', 'Grievance', id, `Assigned to ${assigneeId}`);
  return updated;
}