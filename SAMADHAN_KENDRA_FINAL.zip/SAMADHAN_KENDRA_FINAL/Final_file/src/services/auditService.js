import { AuditLog } from '../models/AuditLog.js';

export async function addAudit(actorId, action, resource, resourceId, details, ip) {
  try {
    await AuditLog.create({
      actor: actorId || null,
      action,
      resource,
      resourceId: resourceId?.toString(),
      details,
      ip
    });
  } catch (e) {
    console.warn('Audit failed:', e.message);
  }
}

export function listAudit(limit = 200) {
  return AuditLog.find({})
    .sort({ _id: -1 })
    .limit(limit)
    .populate('actor', 'username role')
    .lean();
}