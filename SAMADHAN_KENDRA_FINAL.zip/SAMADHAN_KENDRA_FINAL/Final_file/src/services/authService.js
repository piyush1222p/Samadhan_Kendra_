import ms from 'ms';
import { User } from '../models/User.js';
import { RefreshToken } from '../models/RefreshToken.js';
import { hashPassword, verifyPassword } from '../utils/password.js';
import { signAccessToken, signRefreshToken, verifyRefresh } from '../utils/jwt.js';
import { addAudit } from './auditService.js';
import { config } from '../config.js';

export async function registerUser({ username, email, password, city }) {
  const existing = await User.findOne({ $or: [{ username }, { email }] });
  if (existing) throw Object.assign(new Error('User with that username or email exists'), { status: 409 });
  const passwordHash = await hashPassword(password);
  const user = await User.create({ username, email, passwordHash, city });
  await addAudit(user._id, 'create', 'User', user._id, 'Registered');
  return user;
}

export async function loginUser({ usernameOrEmail, password }) {
  const user = await User.findOne({
    $or: [{ username: usernameOrEmail }, { email: usernameOrEmail }]
  });
  if (!user) throw Object.assign(new Error('Invalid credentials'), { status: 401 });
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) throw Object.assign(new Error('Invalid credentials'), { status: 401 });

  const accessToken = signAccessToken({ sub: user._id.toString(), role: user.role });
  const refreshToken = signRefreshToken({ sub: user._id.toString() });

  const expiresAt = new Date(Date.now() + ms(config.jwt.refreshExpires));
  await RefreshToken.create({ token: refreshToken, user: user._id, expiresAt });
  await addAudit(user._id, 'login', 'User', user._id, 'Login');
  return {
    user: { id: user._id, username: user.username, role: user.role, email: user.email },
    accessToken,
    refreshToken
  };
}

export async function refreshTokens(oldToken) {
  let decoded;
  try {
    decoded = verifyRefresh(oldToken);
  } catch {
    throw Object.assign(new Error('Invalid refresh token'), { status: 401 });
  }
  const stored = await RefreshToken.findOne({ token: oldToken });
  if (!stored || stored.expiresAt < new Date()) {
    throw Object.assign(new Error('Refresh token expired'), { status: 401 });
  }
  const user = await User.findById(decoded.sub);
  if (!user) throw Object.assign(new Error('User not found'), { status: 401 });
  const accessToken = signAccessToken({ sub: user._id.toString(), role: user.role });
  return { accessToken };
}

export async function revokeRefresh(token, userId) {
  await RefreshToken.deleteMany({ token, user: userId });
  await addAudit(userId, 'logout', 'User', userId, 'Logout');
}