import { SupportMessage } from '../models/SupportMessage.js';
import { addAudit } from './auditService.js';

export async function createSupportMessage(data, user) {
  const saved = await SupportMessage.create({
    firstName: data.first_name,
    lastName: data.last_name,
    email: data.email,
    phone: data.phone,
    city: data.city,
    subject: data.subject,
    priority: data.priority,
    message: data.message,
    clientTs: data.client_ts ? new Date(data.client_ts) : null,
    userAgent: data.user_agent,
    user: user?.id
  });
  await addAudit(user?.id, 'create', 'SupportMessage', saved._id, 'Submitted support message');
  return saved;
}