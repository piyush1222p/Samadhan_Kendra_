import { Department } from '../models/Department.js';
import { addAudit } from './auditService.js';

export function listDepartments() {
  return Department.find({}).sort({ name: 1 }).lean();
}

export async function createDepartment(name, actorId) {
  const dep = await Department.create({ name });
  await addAudit(actorId, 'create', 'Department', dep._id, `Created ${name}`);
  return dep;
}