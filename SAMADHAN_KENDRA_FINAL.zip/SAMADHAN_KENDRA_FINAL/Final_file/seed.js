import 'dotenv/config';
import mongoose from 'mongoose';
import bcrypt from 'bcrypt';
import { User } from './src/models/User.js';
import { Department } from './src/models/Department.js';

async function run() {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('Mongo connected (seed)');

  // Helper to ensure user
  async function ensureUser(username, role, password = 'password123') {
    let u = await User.findOne({ username });
    if (!u) {
      const hash = await bcrypt.hash(password, 10);
      u = await User.create({
        username,
        passwordHash: hash,
        role: role.toUpperCase(),
        status: 'ACTIVE'
      });
      console.log(`Created user: ${username} (${role})`);
    } else {
      let changed = false;
      if (u.role !== role.toUpperCase()) { u.role = role.toUpperCase(); changed = true; }
      if (u.status !== 'ACTIVE') { u.status = 'ACTIVE'; changed = true; }
      if (changed) { await u.save(); console.log(`Normalized user: ${username}`); }
      else console.log(`User exists: ${username}`);
    }
    return u;
  }

  await ensureUser('admin', 'ADMIN', 'admin123');
  await ensureUser('moderator', 'MODERATOR', 'moderator123');
  await ensureUser('user1', 'USER', 'user123');

  // Departments sample (adjust names)
  const deptNames = ['Water', 'Electricity', 'Roads'];
  for (const name of deptNames) {
    const existing = await Department.findOne({ name });
    if (!existing) {
      await Department.create({ name, description: `${name} related grievances` });
      console.log('Created department:', name);
    }
  }

  console.log('Seed complete');
  await mongoose.disconnect();
}

run().catch(e => {
  console.error('Seed error', e);
  process.exit(1);
});