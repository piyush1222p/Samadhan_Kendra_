# Samadhan Kendra MongoDB Backend

## 1. Setup
cp .env.example .env
# Edit JWT secrets & MONGO_URI if needed

npm install
npm run seed
npm run dev

## 2. Verify
Health:
curl http://localhost:8000/api/health

Login (after seed):
curl -X POST http://localhost:8000/api/auth/login -H "Content-Type: application/json" -d '{"username":"admin","password":"admin123"}'

Store accessToken, then:
curl -H "Authorization: Bearer ACCESS_TOKEN" http://localhost:8000/api/departments

## 3. Create Grievance
curl -X POST http://localhost:8000/api/grievances \
 -H "Authorization: Bearer ACCESS_TOKEN" \
 -H "Content-Type: application/json" \
 -d '{"title":"Broken streetlight","description":"Light not working","priority":"high","department":"DEPARTMENT_ID"}'

List:
curl -H "Authorization: Bearer ACCESS_TOKEN" http://localhost:8000/api/grievances

## 4. Status Update
curl -X PATCH http://localhost:8000/api/grievances/GRIEVANCE_ID/status \
 -H "Authorization: Bearer ACCESS_TOKEN" \
 -H "Content-Type: application/json" \
 -d '{"status":"investigating"}'

## 5. Support
curl -X POST http://localhost:8000/api/support/contact \
 -H "Content-Type: application/json" \
 -d '{"first_name":"Test","last_name":"U","email":"t@example.com","city":"mumbai","subject":"Help","priority":"high","message":"Check"}'

## 6. Audit Logs (ADMIN)
curl -H "Authorization: Bearer ACCESS_TOKEN" http://localhost:8000/api/audit

## 7. Notes
- Status values accepted: reported, investigating, in-progress, resolved
- Priority mapping: low=1, medium=2, high=3, urgent=4 (numbers also accepted)
- Refresh token flow: POST /api/auth/refresh {refreshToken}
- Logout: POST /api/auth/logout (with access token + body refreshToken)