(async () => {
  const files = [
    '../src/controllers/authController.js',
    '../src/controllers/departmentController.js',
    '../src/controllers/grievanceController.js',
    '../src/controllers/supportController.js',
    '../src/middleware/auth.js'
  ];
  for (const f of files) {
    try {
      const mod = await import(f);
      console.log(f, '->', Object.keys(mod));
    } catch (e) {
      console.error('ERROR importing', f, '-', e.message);
    }
  }
})();