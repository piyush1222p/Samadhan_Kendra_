import 'dotenv/config';
import mongoose from 'mongoose';
import { Grievance } from '../src/models/Grievance.js';

await mongoose.connect(process.env.MONGO_URI);
console.log('Connected. Ensuring indexes...');
await Grievance.syncIndexes(); // compares and creates/drops
console.log('Indexes synchronized.');
await mongoose.disconnect();