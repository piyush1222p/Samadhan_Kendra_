/**
 * Migration script to normalize legacy grievance documents into the new schema:
 *  - Convert string priorities (low/medium/high/urgent) to numeric 1–4
 *  - Map old/lowercase status values to new uppercase enum:
 *      REPORTED, INVESTIGATING, IN_PROGRESS, RESOLVED
 *
 * Run with: node scripts/migrateGrievances.js
 *
 * Make sure:
 *  - .env has MONGO_URI
 *  - Your updated Grievance model is already in src/models/Grievance.js
 */

import 'dotenv/config';
import mongoose from 'mongoose';
import { Grievance } from '../src/models/Grievance.js';

const PRIORITY_MAP = {
  '1': 1,
  '2': 2,
  '3': 3,
  '4': 4,
  low: 1,
  medium: 2,
  med: 2,
  high: 3,
  urgent: 4,
  critical: 4
};

const STATUS_MAP = {
  open: 'REPORTED',
  reported: 'REPORTED',
  'in-progress': 'IN_PROGRESS',
  'in_progress': 'IN_PROGRESS',
  inprogress: 'IN_PROGRESS',
  investigating: 'INVESTIGATING',
  investigation: 'INVESTIGATING',
  resolved: 'RESOLVED',
  closed: 'RESOLVED'
};

async function run() {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    console.error('MONGO_URI not set in .env');
    process.exit(1);
  }
  await mongoose.connect(uri);
  console.log('[migrate] Connected to Mongo');

  const cursor = Grievance.find().cursor();
  let scanned = 0;
  let changed = 0;
  for (let g = await cursor.next(); g != null; g = await cursor.next()) {
    scanned++;
    let modify = false;

    // Priority normalization
    if (typeof g.priority === 'string') {
      const key = g.priority.toLowerCase();
      if (PRIORITY_MAP[key] && PRIORITY_MAP[key] !== g.priority) {
        g.priority = PRIORITY_MAP[key];
        modify = true;
      }
    } else if (typeof g.priority === 'number') {
      if (![1, 2, 3, 4].includes(g.priority)) {
        // If out of range, default to 2 (MEDIUM)
        g.priority = 2;
        modify = true;
      }
    } else if (g.priority == null) {
      g.priority = 2;
      modify = true;
    }

    // Status normalization
    if (g.status) {
      const raw = g.status.toString().toLowerCase();
      if (STATUS_MAP[raw] && STATUS_MAP[raw] !== g.status) {
        g.status = STATUS_MAP[raw];
        modify = true;
      }
    } else {
      g.status = 'REPORTED';
      modify = true;
    }

    if (modify) {
      await g.save();
      changed++;
      if (changed % 50 === 0) {
        console.log(`[migrate] Updated ${changed} so far...`);
      }
    }
  }

  console.log(`[migrate] Scanned: ${scanned}, Modified: ${changed}`);
  await mongoose.disconnect();
  console.log('[migrate] Done.');
}

run().catch(err => {
  console.error('[migrate] Error', err);
  process.exit(1);
});