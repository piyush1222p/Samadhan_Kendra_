import 'dotenv/config';
import mongoose from 'mongoose';
import { Grievance } from '../src/models/Grievance.js';

(async () => {
  try {
    if (!process.env.MONGO_URI) {
      console.error('MONGO_URI missing in .env');
      process.exit(1);
    }
    await mongoose.connect(process.env.MONGO_URI);
    const indexes = await Grievance.collection.indexes();
    console.log('Grievance indexes:');
    for (const ix of indexes) {
      console.log('-', ix.name, ix.key);
    }
  } catch (e) {
    console.error('Error listing indexes:', e);
  } finally {
    await mongoose.disconnect();
  }
})();